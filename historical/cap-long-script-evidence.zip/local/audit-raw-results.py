from pathlib import Path
import csv, statistics, math, json
root=Path(__file__).resolve().parents[1]/'cap-gpui-long-script-performance/evidence'
results={}
for kind,pairs,folder,ratio_col in [('viewport',3,root/'viewport-core-results','median_paired_speedup'),('helper',5,root/'grapheme-probe/production-results','speedup')]:
 summary=list(csv.DictReader((folder/'summary.csv').open()))
 keys=list(summary[0]); first_metric=keys.index('baseline_median_ns'); keys=keys[:first_metric]
 groups={}; total=0
 for pair in range(1,pairs+1):
  for variant in ['baseline','candidate']:
   rows=list(csv.DictReader((folder/f'pair-{pair}-{variant}.csv').open()))
   seen=set(); samples={}
   for r in rows:
    k=tuple(r[x] for x in keys); ident=(k,r['sample']); assert ident not in seen; seen.add(ident)
    t=float(r['ns_per_step']); assert math.isfinite(t) and t>0
    samples.setdefault(k,[]).append(t)
   for k,v in samples.items():
    assert len(v)==7
    groups.setdefault(k,{})[(pair,variant)]=statistics.median(v)
   total+=len(rows)
 assert len(summary)==len(groups)
 for r in summary:
  k=tuple(r[x] for x in keys); g=groups[k]
  baseline=[g[p,'baseline'] for p in range(1,pairs+1)]; candidate=[g[p,'candidate'] for p in range(1,pairs+1)]
  for col,v in [('baseline_median_ns',statistics.median(baseline)),('candidate_median_ns',statistics.median(candidate)),(ratio_col,statistics.median([a/b for a,b in zip(baseline,candidate)]))]:
   assert math.isclose(float(r[col]),v,rel_tol=1e-12),(k,col,r[col],v)
 results[kind]={'raw_samples':total,'cases':len(summary),'mismatches':0}
print(json.dumps(results,indent=2))
