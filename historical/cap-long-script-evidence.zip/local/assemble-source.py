from pathlib import Path
import sys,hashlib
out=Path(__file__).resolve().parent
kind=sys.argv[1]
assert kind in ['baseline','candidate']
original=(out/f'{kind}-original.rs').read_text()
if kind=='candidate': assert hashlib.sha256(original.encode()).hexdigest()=='061b686f349bd15b99986efd74134688ac8f27bb521678033fae57b5a6e16dc3'
evidence=out.parent/'cap-gpui-long-script-performance/evidence'
includes=[evidence/'text-input-viewport-benchmark.rs',out/'independent-text-input.rs',out/'layout-cache-diagnostic-baseline.rs' if kind=='baseline' else evidence/'layout-cache-diagnostic.rs']
s=original
for p in includes:s+=f'\n#[cfg(test)]\ninclude!("{p}");\n'
s+=f'\n#[cfg(not(test))]\ninclude!("{out}/native-module.rs");\n'
(out.parent/'Cap/apps/desktop-gpui/src/ui/text_input.rs').write_text(s)
print('Assembled',kind)
