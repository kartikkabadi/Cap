from pathlib import Path
import csv,json,statistics,math
p=Path(__file__).resolve().parent
v=list(csv.DictReader((p/'viewport-results/summary.csv').open()))
h=list(csv.DictReader((p/'helper-final/summary.csv').open()))
assert len(v)==66 and len(h)==94
summary={'viewport':{},'ascii_middle':[],'navigation_examples':[],'small_control_regressions':[]}
for target in ['10000','100000']:
 summary['viewport'][target]={}
 for scope in ['key_dispatch','scroll_redraw']:
  rows=[r for r in v if r['target_bytes']==target and r['scope']==scope]
  values=[float(r['median_paired_speedup']) for r in rows]
  summary['viewport'][target][scope]={'speedup_min':min(values),'speedup_max':max(values)}
 for scope,motion in [('key_dispatch','left'),('key_dispatch','right'),('scroll_redraw','none')]:
  rows=[r for r in v if r['target_bytes']==target and r['kind']=='ascii' and r['region']=='middle' and r['scope']==scope and r['motion']==motion]
  assert len(rows)==1,rows
  r=rows[0]
  summary['ascii_middle'].append({'bytes':int(target),'scope':scope,'motion':motion,'baseline_us':float(r['baseline_median_ns'])/1000,'candidate_us':float(r['candidate_median_ns'])/1000,'paired_speedup':float(r['median_paired_speedup']),'paired_min':float(r['paired_min']),'paired_max':float(r['paired_max'])})
for r in h:
 if r['case']=='script_ascii_100000' and r['region']=='middle' and r['operation']=='query':summary['navigation_examples'].append(r)
 if r['case'].startswith('control_') and float(r['speedup'])<1: summary['small_control_regressions'].append(r)
for folder,pairs,ratio_col in [(p/'viewport-results',3,'median_paired_speedup'),(p/'helper-final',5,'speedup')]:
 rows=list(csv.DictReader((folder/'summary.csv').open())); columns=list(rows[0]);keys=columns[:columns.index('baseline_median_ns')];g={}
 for pair in range(1,pairs+1):
  for variant in ['baseline','candidate']:
   samples={}
   for r in csv.DictReader((folder/f'pair-{pair}-{variant}.csv').open()):
    k=tuple(r[f] for f in keys);samples.setdefault(k,[]).append((int(r['sample']),float(r['ns_per_step'])))
   assert len(samples)==len(rows)
   for k,s in samples.items():
    assert sorted(i for i,t in s)==(list(range(1,8)) if folder.name=='viewport-results' else list(range(7)));assert all(t>0 and math.isfinite(t) for i,t in s)
    g.setdefault(k,{})[pair,variant]=statistics.median(t for i,t in s)
 for r in rows:
  k=tuple(r[f] for f in keys);samples=g[k]
  before=[samples[i,'baseline'] for i in range(1,pairs+1)];after=[samples[i,'candidate'] for i in range(1,pairs+1)]
  for col,val in [('baseline_median_ns',statistics.median(before)),('candidate_median_ns',statistics.median(after)),(ratio_col,statistics.median(a/b for a,b in zip(before,after)))]:assert math.isclose(float(r[col]),val,rel_tol=1e-12)
(p/'local-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
