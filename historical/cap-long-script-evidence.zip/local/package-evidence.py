from pathlib import Path
import json,hashlib,zipfile
root=Path(__file__).resolve().parents[2];p=root/'work/review';src=root/'work/cap-gpui-long-script-performance';out=root/'outputs/cap-long-script-evidence.zip'
files={}
def add(path,name):
 assert path.is_file() and not path.is_symlink(),path
 assert name not in files,name
 files[name]=path
add(p/'EVIDENCE-README.md','README.md')
add(root/'outputs/cap-long-script-review.md','cap-long-script-review.md')
for n in ['changes.patch','commits.mbox','CAP-LICENSE']:add(src/n,'submission/'+n)
for q in p.iterdir():
 if q.is_file() and q.suffix in ['.rs','.py','.sh','.log','.json','.jsonl','.diff'] and not q.name.startswith('helper-run'):
  add(q,'local/'+q.name)
for folder in ['viewport-results','helper-final','native-baseline','native-candidate']:
 for q in (p/folder).rglob('*'):
  if q.is_file():add(q,'local/'+str(q.relative_to(p)))
for n in ['run-viewport-pairs.py','text-input-viewport-benchmark.rs','layout-cache-diagnostic.rs']:add(src/'evidence'/n,'runners/'+n)
probe=src/'evidence/grapheme-probe'
for q in probe.iterdir():
 if q.is_file() and q.suffix in ['.py','.json','.toml','.lock','.md']:add(q,'runners/grapheme-probe/'+q.name)
for folder in ['src','unicode-conformance']:
 for q in (probe/folder).rglob('*'):
  if q.is_file():add(q,'runners/grapheme-probe/'+str(q.relative_to(probe)))
manifest={'files':[{ 'path':n,'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()} for n,q in sorted(files.items())]}
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(files)+1
 for x in manifest['files']:
  b=z.read(x['path']);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
print(json.dumps({'artifact':str(out),'files':len(files),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'all_entries_verified':True},indent=2))
