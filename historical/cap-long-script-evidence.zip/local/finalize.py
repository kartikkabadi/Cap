from pathlib import Path
import json,hashlib,csv,datetime,zipfile
root=Path(__file__).resolve().parents[2];p=root/'work/review';bundle=root/'work/cap-gpui-long-script-performance';outputs=root/'outputs'
def sha(q): return hashlib.sha256(q.read_bytes()).hexdigest()
def ref(q):return {'path':str(q),'sha256':sha(q)}
result=json.loads((p/'local-results.json').read_text());vp=json.loads((p/'viewport-results/metadata.json').read_text())
profiles={n:json.loads((p/f'{n}-profile.json').read_text()) for n in ['baseline','candidate']}
assert profiles['baseline']['profile']==profiles['candidate']['profile']
assert profiles['baseline']['features']==profiles['candidate']['features']
provenance={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':json.loads((p/'environment.json').read_text()),'upstream_final':'6f81ac9662c01748caac76a1d6424043be736550','upstream_compatibility':'patch applies; only target-file upstream delta is is_focused accessor; tests use fixed base','source':{n:ref(p/f'{n}-original.rs') for n in ['baseline','candidate']},'builds':{n:{'profile':ref(p/f'{n}-profile.json'),'jsonl':ref(p/f'{n}-build.jsonl'),'stderr':ref(p/f'{n}-build.log'),'test_binary':ref(p/f'bin/{n}-gpui-tests'),'native_binary':ref(p/f'bin/{n}-native')} for n in ['baseline','candidate']},'sample_audit':{'viewport_cases':66,'viewport_pairs':3,'viewport_samples':2772,'helper_cases':94,'helper_pairs':5,'helper_samples':6580,'summary_discrepancies':0},'source_restored':True,'scope_files':1,'diff':{'insertions':673,'deletions':71,'production_insertions':200,'production_deletions':69},'no_push_or_pr':True,'metadata_note':'The viewport runner records original bundled build-log references by directory convention. Actual local build references above are authoritative; executable and explicit profile references in raw metadata are already correct. Raw metadata and timing values are preserved.'}
provenance['environment']['upstream_final']=provenance['upstream_final']
(p/'local-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
report='''# Cap long-script text input: independent local review

**Verdict: legitimate performance improvement; no blocking correctness defect found.** The archive's arithmetic checks out, the improvement reproduces on this Mac, and the tested output remains unchanged. No production fix was needed during review. Nothing was committed, pushed or opened as a PR in this audit.

## What changes

The entire submitted patch changes `apps/desktop-gpui/src/ui/text_input.rs`: **+673 / −71 lines**, consisting of **+200 / −69 production** and **+473 / −2 test** lines. Benchmarks and evidence are outside the repository patch. No dependencies or generated files change.

The three mechanisms address observed work: grapheme navigation begins at the caret; layout measurement retains the active interaction rows rather than replacing them at each probed width; painting rejects fully clipped unmarked paragraphs before GPUI's per-glyph loop. One active layout and at most four alternate width/size entries are retained. Full font and color participate in cache invalidation, and inherited font state is captured before deferred measurement.

This shared component also serves settings, search, rename, editor and annotation inputs. Review covered their layout and state dependencies, cache invalidation, UTF-8/UTF-16 editing, selection, hit testing, alignment, composition marking, resize behavior, and GPUI's actual glyph clipping rules. The fractional-line-height fallback is necessary: GPUI's repeated floating-point additions can differ from row-count multiplication.

## Measurements reproduced on this Mac

Apple M1 Pro, eight logical CPUs, 16 GiB RAM, macOS 27.0.1, Rust 1.95.0. Baseline and candidate used matching locked dependencies and optimized app test settings: opt-level 3, debug info off, debug assertions and overflow checks on. These are optimized test binaries, not shipping release builds.

Three alternating fresh process pairs, seven samples per case, 120 operations per sample, 66 cases covering ASCII, multilingual and emoji scripts:

| UTF-8 script size | Key dispatch + CPU drawing | Scroll CPU redraw |
| --- | ---: | ---: |
'''
for n,label in [('10000','10,000 bytes'),('100000','100,000 bytes')]:
 a=result['viewport'][n]['key_dispatch'];b=result['viewport'][n]['scroll_redraw'];report+=f"| {label} | {a['speedup_min']:.1f}–{a['speedup_max']:.1f}× | {b['speedup_min']:.1f}–{b['speedup_max']:.1f}× |\n"
report+='''
Representative ASCII cases near the middle of a 100,000-byte script:

| Operation | Baseline median | Candidate median | Median paired speedup | Paired range |
| --- | ---: | ---: | ---: | ---: |
'''
for r in result['ascii_middle']:
 if r['bytes']!=100000:continue
 label='Scroll redraw' if r['scope']=='scroll_redraw' else ('Left arrow' if r['motion']=='left' else 'Right arrow')
 report+=f"| {label} | {r['baseline_us']/1000:.3f} ms | {r['candidate_us']:.3f} µs | {r['paired_speedup']:.1f}× | {r['paired_min']:.1f}–{r['paired_max']:.1f}× |\n"
report+='''
The absolute times are medians of process medians. Speedups are medians of paired ratios; dividing the two displayed time medians can therefore give a different number.

All 2,772 viewport samples and 6,580 final helper samples were independently regrouped and recalculated with zero discrepancies. The separate helper benchmark used five alternating process pairs across 94 cases. Middle-of-script ASCII previous/next queries improved about **40,868× / 45,715×**, respectively. None of the small helper control cases measured a slowdown. Helper ratios describe only boundary lookup, not complete input latency.

The host was shared, with no CPU affinity or power-state control. The third baseline viewport process took 441.8 seconds versus 215.8/217.9 seconds for the first two; its data is retained. Paired ranges above expose that variation. Candidate process runtimes were 2.26–2.34 seconds. Treat precise ratios as environment-specific; the large improvement is consistent across the compared workloads. Exploratory helper timings collected during compilation were excluded; final comparisons ran serially after compilation.

The original Linux archive reports 73.34–174.88× key/CPU-draw and 101.90–192.55× scroll speedups for 100 KB scripts. All of its 9,352 recorded samples independently reproduce its summaries. Those Linux measurements and this Mac's results are separate observations.

## Correctness and regression evidence

- **1,361 candidate app tests passed, zero failed, 19 ignored.** This includes all 32 supplied TextInput tests and two additional independent checks. The two relevant ignored audit probes—cache diagnostic and viewport benchmark—were subsequently run explicitly; the other 17 ignored tests were not executed.
- Baseline regular TextInput tests passed. The actual-window cache diagnostic intentionally fails on the baseline and passes on the candidate for right-arrow, Shift-right and scroll. It demonstrates that the optimization removes real repeated row reconstruction.
- **374,742 byte offsets passed in both directions**, including 766 official Unicode 17.0 conformance cases and 7,801 official-case offsets. Tests cover contextual clusters, interior UTF-8 offsets and offsets beyond the text. Official conformance-source hashes match the pinned unicode-segmentation 1.13.3 crate.
- **480 independent geometry/selection/hit-test snapshots matched exactly** between baseline and candidate: empty and Unicode text, single/multiline/fit-content inputs, three alignments, cold/warm frames and four resize widths.
- Independent composition/edit/undo/redo checks passed on both versions.
- **108 actual native font/Metal captures matched exactly**, both RGBA pixels and encoded PNG bytes. Cases include wrapping, Unicode, empty paragraphs, a single long paragraph, selection, composition marking, top/middle/bottom scroll positions and fractional line heights. Every capture asserts that visible text was rendered. Four additional cached-versus-fresh native font/color comparisons passed on both versions.
- Binary-and-test Clippy/type checks succeeded on both versions with the **same 30 pre-existing app diagnostics, zero new diagnostics and none in the changed file**. This is not a `-D warnings` clean claim. Rust 1.95.0 rustfmt and patch whitespace checks passed on the final unchanged source.

Native rendering uses the real production text component and keyboard navigation, an offscreen GPUI window, the Mac font system and Metal, with a fixed test theme and isolated profile. It is component rendering validation, not full signed-in application acceptance.

## Integrity, upstream and duplicate review

- Input: `cap-gpui-long-script-performance.zip`, SHA-256 `095075c620b3a990575b6601cd33455cf753470d9cafd818409a5288621b666a`. All 105 manifest entries matched their recorded sizes and hashes.
- Fixed test base: `f510acfa1846552a490bfcc3267910218c606364`.
- Candidate source SHA-256: `061b686f349bd15b99986efd74134688ac8f27bb521678033fae57b5a6e16dc3`.
- The combined patch and both mbox commits independently produce the same final source through isolated Git indexes/object storage. Final checkout contains only the one intended source change, with no audit hooks or temporary example left in the patch. The primary clone remains clean.
- The patch applies cleanly to final inspected upstream `6f81ac9662c01748caac76a1d6424043be736550`. Upstream's only change to this file since the fixed base is a five-line `is_focused` accessor outside the changed methods. Runtime tests use the immutable archive base, not all newer upstream changes.
- Inspected changed-file lists for 153 open PRs, then refreshed the 30 most recently updated open PRs. The only initial target-file overlap, [#2587](https://github.com/CapSoftware/Cap/pull/2587), changes theme styling and does not implement these mechanisms. Historical matches [#2773](https://github.com/CapSoftware/Cap/pull/2773) and [#2524](https://github.com/CapSoftware/Cap/pull/2524) concern platform shortcuts and a separate renderer cache. The earlier [#3112](https://github.com/CapSoftware/Cap/pull/3112) active-style renderer optimization is independent. **No equivalent published implementation was found in this audit.**

## Limits and recommendation

The performance measurements cover warmed CPU work with GPUI's synthetic text metrics. They establish neither native display latency nor FPS, OS input latency, GPU throughput, recording or export throughput. Native output was checked separately, without timing it. Full signed-in UI workflows, system IME event entry, Windows/Linux native execution and release-profile performance remain untested locally.

Cold layout, text edits, changing widths/styles and long contextual Unicode clusters can still require substantial work. Marked composition deliberately bypasses paragraph culling. There is no claim that every editing operation becomes constant-time or that every workload gains the headline ratio.

**Recommendation:** keep the implementation and its regression tests. I found no reason for a safety rewrite or additional production code. Keep benchmark evidence outside the repository diff and use the scoped CPU measurements in any future PR description. A future PR should recheck current main and published overlap before submission.

`cap-long-script-evidence.zip` accompanies this report with the patch, independent fixtures, raw final measurements, build/test records, native captures, provenance and a checksum manifest. No push or PR has been made.
'''
(outputs/'cap-long-script-review.md').write_text(report)
(p/'plan.md').write_text('# Cap long-script input audit\n\nAll five review phases complete. No blocking correctness findings. Original candidate unchanged, one-file patch restored. Full candidate suite, independent regression/native rendering checks, baseline comparisons, Clippy, Unicode conformance, final serial paired measurements, raw-data recalculation, integrity and published-overlap review completed. Details and limits are in outputs/cap-long-script-review.md. No push, PR or commit.\n')
print('Final report and provenance written')
