#!/usr/bin/env bash
set -euo pipefail
review_dir="/Users/user/Documents/Codex/2026-10-24/ok-x20/work/review"
repo_dir="/Users/user/Documents/Codex/2026-10-24/ok-x20/work/Cap"
variant="$1"
cd "$repo_dir"
export CARGO_INCREMENTAL=0
export CARGO_TARGET_DIR="/Users/user/Documents/Codex/2026-10-24/ok-x20/work/gpui-target"
mkdir -p "$CARGO_TARGET_DIR/debug/Frameworks" "$review_dir/bin"
ln -sfn "$repo_dir/target/Frameworks/Spacedrive.framework" "$CARGO_TARGET_DIR/debug/Frameworks/Spacedrive.framework"
cargo +1.95.0 test --manifest-path apps/desktop-gpui/Cargo.toml --locked --bin cap-gpui --no-run \
 --config profile.dev.package.cap-desktop-gpui.opt-level=3 \
 --config profile.dev.package.cap-desktop-gpui.debug=0 \
 --config 'profile.dev.package."*".debug=0' --message-format=json > "$review_dir/$variant-build.jsonl" 2> "$review_dir/$variant-build.log"
python3 - "$review_dir" "$variant" <<'PY'
import sys,json,shutil,hashlib
from pathlib import Path
out=Path(sys.argv[1]); name=sys.argv[2]
records=[json.loads(line) for line in (out/f'{name}-build.jsonl').read_text().splitlines()]
artifact=next(x for x in reversed(records) if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']=='cap-gpui')
executable=out/'bin'/f'{name}-gpui-tests'
shutil.copy2(artifact['executable'],executable)
(out/f'{name}-profile.json').write_text(json.dumps(artifact,indent=2)+'\n')
print(name,executable,hashlib.sha256(executable.read_bytes()).hexdigest())
PY
