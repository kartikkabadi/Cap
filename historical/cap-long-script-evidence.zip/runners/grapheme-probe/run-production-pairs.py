import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import shutil
from datetime import datetime, timezone

parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path)
parser.add_argument("--bundled-sources", action="store_true")
parser.add_argument("--offline", action="store_true")
parser.add_argument("--output", type=Path)
parser.add_argument("--pairs", type=int, default=5)
parser.add_argument("--sample-ms", type=float, default=10)
parser.add_argument("--cpu", type=int)
args = parser.parse_args()
here = Path(__file__).resolve().parent
base = here.parents[1]
repo = (args.repo or base / "cap-gpui-next").resolve()
env = os.environ.copy()
tooling = base / ".tooling"
if (tooling / "cargo/bin/cargo").is_file():
    env.setdefault("RUSTUP_HOME", str(tooling / "rustup"))
    env.setdefault("CARGO_HOME", str(tooling / "cargo"))
    cargo = str(tooling / "cargo/bin/cargo")
    rustc = str(tooling / "cargo/bin/rustc")
else:
    cargo = shutil.which("cargo")
    rustc = shutil.which("rustc")
    assert cargo and rustc, "Rust 1.95.0 must be available through rustup"
if not args.bundled_sources:
    subprocess.run(["python3", str(here / "extract-production.py"), "--repo", str(repo)], cwd=here, env=env, check=True)
build = [cargo, "+1.95.0", "build", "--release", "--locked", "--bin", "grapheme-production-benchmark"]
if args.offline:
    build.append("--offline")
subprocess.run(build, cwd=here, env=env, check=True)
binary = here / "target/release/grapheme-production-benchmark"
command = [str(binary)]
if args.cpu is not None:
    command = ["taskset", "--cpu-list", str(args.cpu), *command]
results = args.output or here / "reproduced-results"
results.mkdir(parents=True, exist_ok=True)
cpu_info = Path("/proc/cpuinfo")
cpu_model = next(
    (line.split(":", 1)[1].strip() for line in (cpu_info.read_text().splitlines() if cpu_info.exists() else [])
     if line.startswith("model name")),
    platform.processor() or "unknown",
)
metadata = {
    "started_at_utc": datetime.now(timezone.utc).isoformat(),
    "rustc": subprocess.check_output([rustc, "+1.95.0", "-Vv"], env=env, text=True),
    "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
    "source": json.loads((here / "production-extraction.json").read_text()),
    "environment": {
        **json.loads((here / "environment.json").read_text()),
        "platform": platform.platform(),
        "cpu": cpu_model,
        "cpu_affinity": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "target_sample_ms": args.sample_ms,
    },
    "source_mode": "bundled" if args.bundled_sources else "extracted from repo",
    "pairs": args.pairs,
    "samples_per_case": 7,
    "target_sample_ms": args.sample_ms,
    "cpu": args.cpu,
}
(results / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
env["CAP_GRAPHEME_SAMPLE_MS"] = str(args.sample_ms)


def run(name, extra):
    print(f"Running {name}", flush=True)
    temporary = results / f"{name}.csv.tmp"
    with temporary.open("w") as output, (results / f"{name}.log").open("w") as error:
        subprocess.run(command, cwd=here, env={**env, **extra}, stdout=output, stderr=error, check=True)
    temporary.replace(results / f"{name}.csv")


run("verification", {"CAP_GRAPHEME_VERIFY_ONLY": "1"})
run("alternating-samples", {"CAP_GRAPHEME_SKIP_VERIFY": "1", "CAP_GRAPHEME_VARIANT": "both"})
for pair in range(args.pairs):
    order = ["baseline", "candidate"] if pair % 2 == 0 else ["candidate", "baseline"]
    for variant in order:
        run(f"pair-{pair + 1}-{variant}", {"CAP_GRAPHEME_SKIP_VERIFY": "1", "CAP_GRAPHEME_VARIANT": variant})

keys = ["case", "bytes", "characters", "words", "region", "direction", "operation", "steps"]
process_medians = {}
for pair in range(args.pairs):
    for variant in ["baseline", "candidate"]:
        grouped = {}
        with (results / f"pair-{pair + 1}-{variant}.csv").open() as file:
            for row in csv.DictReader(file):
                key = tuple(row[field] for field in keys)
                grouped.setdefault(key, []).append(float(row["ns_per_step"]))
        for key, samples in grouped.items():
            assert len(samples) == 7
            process_medians.setdefault(key, {}).setdefault(variant, []).append(statistics.median(samples))
with (results / "summary.csv").open("w") as file:
    writer = csv.writer(file)
    writer.writerow([*keys, "baseline_median_ns", "candidate_median_ns", "speedup", "baseline_process_min_ns", "baseline_process_max_ns", "candidate_process_min_ns", "candidate_process_max_ns", "paired_speedup_min", "paired_speedup_max"])
    for key, variants in process_medians.items():
        baseline = statistics.median(variants["baseline"])
        candidate = statistics.median(variants["candidate"])
        ratios = [before / after for before, after in zip(variants["baseline"], variants["candidate"])]
        writer.writerow([*key, baseline, candidate, statistics.median(ratios), min(variants["baseline"]), max(variants["baseline"]), min(variants["candidate"]), max(variants["candidate"]), min(ratios), max(ratios)])
print(f"Saved {len(process_medians)} comparisons to {results / 'summary.csv'}", flush=True)
