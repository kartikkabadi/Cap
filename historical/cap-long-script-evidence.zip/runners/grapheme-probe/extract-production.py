import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path)
parser.add_argument("--candidate-source", default="apps/desktop-gpui/src/ui/text_input.rs")
args = parser.parse_args()
here = Path(__file__).resolve().parent
repo = (args.repo or here.parents[1] / "cap-gpui-next").resolve()
baseline_commit = "f510acfa1846552a490bfcc3267910218c606364"
relative = "apps/desktop-gpui/src/ui/text_input.rs"


def extract(source):
    functions = []
    locations = {}
    for name in ["previous_grapheme", "next_grapheme"]:
        start = source.index(f"fn {name}(")
        body = source.index("{", start)
        depth = 1
        end = body + 1
        while depth:
            depth += (source[end] == "{") - (source[end] == "}")
            end += 1
        functions.append(source[start:end])
        locations[name] = {
            "line_start": source.count("\n", 0, start) + 1,
            "line_end": source.count("\n", 0, end) + 1,
            "sha256": hashlib.sha256(source[start:end].encode()).hexdigest(),
        }
    return "\n\n".join(functions) + "\n", locations


manifest = {"baseline_commit": baseline_commit, "unicode_segmentation": "1.13.3", "compiler": "1.95.0"}
for variant, raw, path in [
    ("baseline", subprocess.check_output(["git", "show", f"{baseline_commit}:{relative}"], cwd=repo), relative),
    ("candidate", (repo / args.candidate_source).read_bytes(), args.candidate_source),
]:
    extracted, locations = extract(raw.decode())
    (here / f"src/{variant}_helpers.rs").write_text(extracted)
    manifest[variant] = {
        "source": path,
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "extracted_sha256": hashlib.sha256(extracted.encode()).hexdigest(),
        "functions": locations,
    }
manifest["candidate_diff"] = subprocess.check_output(["git", "diff", baseline_commit, "--", args.candidate_source], cwd=repo, text=True)
(here / "production-extraction.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "candidate_diff"}, indent=2))
