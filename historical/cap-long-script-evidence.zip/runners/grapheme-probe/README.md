# Exact GPUI grapheme helper comparison

This standalone crate contains the exact previous_grapheme and next_grapheme definitions extracted from Cap base f510acfa1846552a490bfcc3267910218c606364 and the final candidate. The final-source-match.json record one directory above verifies the candidate definitions against the final commit. Unicode-segmentation is pinned to 1.13.3, matching the GPUI lockfile.

Run with Python 3 and rustup Rust 1.95.0:

```sh
python3 run-production-pairs.py --bundled-sources --pairs 5 --sample-ms 10 --output reproduced-results
```

The bundled-source mode needs no Cap checkout. To extract the same helper names from a checkout instead, replace --bundled-sources with --repo /absolute/path/to/Cap. That checkout must contain the immutable base commit in its history. --offline is optional after fetching the pinned dependency.

Published data remains in production-results/. The runner writes new data to the selected output directory, records the current machine and compiler, verifies equivalence before timing and retains raw samples. See ../BENCHMARKS.md for the full workload, scope and interpretation. Long regional-indicator and combining-mark runs demonstrate that Unicode context can still require long scans.
