use unicode_segmentation::UnicodeSegmentation;

pub(super) fn random(seed: &mut u64) -> u64 {
    *seed ^= *seed << 13;
    *seed ^= *seed >> 7;
    *seed ^= *seed << 17;
    *seed
}

pub(super) fn script(kind: &str, target: usize) -> String {
    let sentences: &[&str] = match kind {
        "ascii" => &[
            "Welcome back. Today we will walk through the recording workflow together.",
            "First, choose the screen you want to share and check that your microphone is ready.",
            "Pause here so the audience has time to follow each step before we continue.",
            "The important detail is how the preview responds while you make an adjustment.",
            "Thanks for watching. You can return to this section whenever you need a reminder.",
        ],
        "multilingual" => &[
            "Bonjour à tous. Aujourd’hui, nous allons préparer une présentation ensemble.",
            "こんにちは。録画する画面を選んで、マイクの設定を確認してください。",
            "नमस्ते दोस्तों। आज हम इस रिकॉर्डिंग की प्रक्रिया को साथ में समझेंगे।",
            "مرحباً بكم. سنتابع الخطوات معاً ونتوقف قليلاً لشرح كل تفصيل.",
            "Gracias por acompañarnos. Revisemos cómo cambia la vista previa al editar.",
        ],
        "emoji" => &[
            "Welcome 👋🏽 to our weekly update. The team 👩🏽‍💻 is ready to share the next steps.",
            "Our colleagues in 🇬🇧 🇯🇵 🇧🇷 helped test the release. Thank you everyone!",
            "Let us pause for a cafe\u{301} ☕ and review what changed in the recording.",
            "The family 👨‍👩‍👧‍👦 will see the result together. Check the preview before continuing.",
            "We made progress 🎉, and the next topic is how to present this clearly to the audience.",
        ],
        _ => unreachable!(),
    };
    let mut seed = 0x6ab2_a603_d814_c9e5;
    let mut text = String::with_capacity(target + 256);
    while text.len() < target {
        text.push_str(sentences[random(&mut seed) as usize % sentences.len()]);
        text.push(if random(&mut seed) % 4 == 0 {
            '\n'
        } else {
            ' '
        });
    }
    let end = text
        .grapheme_indices(true)
        .map(|(index, _)| index)
        .take_while(|index| *index <= target)
        .last()
        .unwrap_or(0);
    text.truncate(end);
    text
}
