use std::{hint::black_box, time::Instant};
use unicode_segmentation::UnicodeSegmentation;

mod fixtures;

mod unicode_conformance {
    include!("../unicode-conformance/grapheme.rs");
}

mod baseline {
    use unicode_segmentation::UnicodeSegmentation;
    include!("baseline_helpers.rs");

    pub(super) fn previous(text: &str, offset: usize) -> usize {
        previous_grapheme(text, offset)
    }

    pub(super) fn next(text: &str, offset: usize) -> usize {
        next_grapheme(text, offset)
    }
}

mod candidate {
    use unicode_segmentation::GraphemeCursor;
    include!("candidate_helpers.rs");

    pub(super) fn previous(text: &str, offset: usize) -> usize {
        previous_grapheme(text, offset)
    }

    pub(super) fn next(text: &str, offset: usize) -> usize {
        next_grapheme(text, offset)
    }
}

type Navigate = fn(&str, usize) -> usize;

#[derive(Clone, Copy)]
enum Direction {
    Previous,
    Next,
}

impl Direction {
    fn name(self) -> &'static str {
        match self {
            Self::Previous => "previous",
            Self::Next => "next",
        }
    }

    fn baseline(self) -> Navigate {
        match self {
            Self::Previous => baseline::previous,
            Self::Next => baseline::next,
        }
    }

    fn candidate(self) -> Navigate {
        match self {
            Self::Previous => candidate::previous,
            Self::Next => candidate::next,
        }
    }
}

enum Operation {
    Queries(Vec<usize>),
    Traversal { start: usize, steps: usize },
}

impl Operation {
    fn steps(&self) -> usize {
        match self {
            Self::Queries(_) => 1,
            Self::Traversal { steps, .. } => *steps,
        }
    }

    fn name(&self) -> &'static str {
        match self {
            Self::Queries(_) => "query",
            Self::Traversal { .. } => "caret_steps",
        }
    }
}

struct Case {
    name: String,
    text: String,
    region: &'static str,
    direction: Direction,
    operation: Operation,
}

fn query_offsets(text: &str, region: &str) -> Vec<usize> {
    let boundaries: Vec<_> = text
        .grapheme_indices(true)
        .map(|(index, _)| index)
        .chain(std::iter::once(text.len()))
        .collect();
    let pivot = match region {
        "start" => 0,
        "middle" => (boundaries.len() / 2).saturating_sub(16),
        "end" => boundaries.len().saturating_sub(32),
        _ => unreachable!(),
    };
    (0..32)
        .map(|i| boundaries[(pivot + i).min(boundaries.len() - 1)])
        .collect()
}

fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    for (name, text) in [
        ("control_empty", ""),
        ("control_ascii_grapheme", "a"),
        ("control_combining_grapheme", "e\u{301}"),
        ("control_emoji_grapheme", "👩🏽‍💻"),
        ("control_rename", "Product demo - October 2026"),
        ("control_search", "recording settings"),
        (
            "control_caption",
            "We will now review the recording together.",
        ),
    ] {
        for direction in [Direction::Previous, Direction::Next] {
            cases.push(Case {
                name: name.to_string(),
                text: text.to_string(),
                region: "all",
                direction,
                operation: Operation::Queries(
                    text.grapheme_indices(true)
                        .map(|(index, _)| index)
                        .chain(std::iter::once(text.len()))
                        .collect(),
                ),
            });
        }
    }
    for target in [1_000, 10_000, 100_000] {
        for kind in ["ascii", "multilingual", "emoji"] {
            let text = fixtures::script(kind, target);
            for region in ["start", "middle", "end"] {
                for direction in [Direction::Previous, Direction::Next] {
                    cases.push(Case {
                        name: format!("script_{kind}_{target}"),
                        text: text.clone(),
                        region,
                        direction,
                        operation: Operation::Queries(query_offsets(&text, region)),
                    });
                }
            }
            let boundaries: Vec<_> = text
                .grapheme_indices(true)
                .map(|(index, _)| index)
                .collect();
            let start = boundaries[boundaries.len() / 2];
            for direction in [Direction::Previous, Direction::Next] {
                cases.push(Case {
                    name: format!("script_{kind}_{target}"),
                    text: text.clone(),
                    region: "middle",
                    direction,
                    operation: Operation::Traversal { start, steps: 120 },
                });
            }
        }
    }
    for length in [128, 4_096] {
        for (kind, text) in [
            ("regional_indicators", "🇬".repeat(length)),
            ("combining_marks", format!("a{}b", "\u{301}".repeat(length))),
        ] {
            for direction in [Direction::Previous, Direction::Next] {
                cases.push(Case {
                    name: format!("context_{kind}_{length}"),
                    text: text.clone(),
                    region: "middle",
                    direction,
                    operation: Operation::Queries(vec![text.floor_char_boundary(text.len() / 2)]),
                });
            }
        }
    }
    cases
}

fn verify_all_offsets(text: &str, direct: bool) -> usize {
    let boundaries: Vec<_> = text
        .grapheme_indices(true)
        .map(|(index, _)| index)
        .collect();
    let mut reverse_boundaries: Vec<_> = text
        .grapheme_indices(true)
        .rev()
        .map(|(index, _)| index)
        .collect();
    reverse_boundaries.reverse();
    for offset in 0..=text.len() + 3 {
        let before = reverse_boundaries.partition_point(|index| *index < offset);
        let previous = before
            .checked_sub(1)
            .map_or(0, |index| reverse_boundaries[index]);
        let after = boundaries.partition_point(|index| *index <= offset);
        let next = boundaries.get(after).copied().unwrap_or(text.len());
        assert_eq!(
            candidate::previous(text, offset),
            previous,
            "previous offset={offset}, text={text:?}"
        );
        assert_eq!(
            candidate::next(text, offset),
            next,
            "next offset={offset}, text={text:?}"
        );
        if direct || offset % 997 == 0 {
            assert_eq!(
                baseline::previous(text, offset),
                previous,
                "original previous offset={offset}, text={text:?}"
            );
            assert_eq!(
                baseline::next(text, offset),
                next,
                "original next offset={offset}, text={text:?}"
            );
        }
    }
    text.len() + 4
}

fn verify_unicode_conformance() -> usize {
    let mut cases = 0;
    let mut offsets = 0;
    for (text, expected) in unicode_conformance::TEST_SAME
        .iter()
        .map(|(text, expected)| (*text, *expected))
        .chain(
            unicode_conformance::TEST_DIFF
                .iter()
                .map(|(text, extended, _)| (*text, *extended)),
        )
    {
        assert_eq!(expected.concat(), text);
        let mut end = 0;
        let starts: Vec<_> = expected
            .iter()
            .map(|grapheme| {
                let start = end;
                end += grapheme.len();
                start
            })
            .collect();
        for offset in 0..=text.len() + 3 {
            let previous = starts
                .iter()
                .copied()
                .take_while(|start| *start < offset)
                .last()
                .unwrap_or(0);
            let next = starts
                .iter()
                .copied()
                .find(|start| *start > offset)
                .unwrap_or(text.len());
            for (name, before, after) in [
                (
                    "baseline",
                    baseline::previous as Navigate,
                    baseline::next as Navigate,
                ),
                (
                    "candidate",
                    candidate::previous as Navigate,
                    candidate::next as Navigate,
                ),
            ] {
                assert_eq!(
                    before(text, offset),
                    previous,
                    "Unicode case {cases}, {name} previous offset={offset}, text={text:?}"
                );
                assert_eq!(
                    after(text, offset),
                    next,
                    "Unicode case {cases}, {name} next offset={offset}, text={text:?}"
                );
            }
            offsets += 1;
        }
        cases += 1;
    }
    eprintln!(
        "Verified Unicode 17.0 extended grapheme conformance: {cases} cases, {offsets} byte offsets in both directions, against official expected chunks."
    );
    offsets
}

fn verify() {
    let cases = [
        "",
        "a",
        "\r\n",
        "a\r\nb",
        "e\u{301}",
        "🇬🇧🇯🇵🇧🇷🇨",
        "👩🏽‍💻👨‍👩‍👧‍👦",
        "हिन्दीक्षत्रिय",
        "\u{600}\u{600}a",
        "a\u{301}\u{200d}👩",
        "\u{200d}👩",
        "a\u{1f3ff}b",
        "각한글",
        "\u{301}\u{301}x",
        "🏴\u{e0067}\u{e0062}\u{e007f}",
    ];
    let mut count = verify_unicode_conformance();
    for text in cases {
        count += verify_all_offsets(text, true);
    }
    for text in [
        "🇬".repeat(129),
        format!("a{}b", "\u{301}".repeat(129)),
        format!("👩{}‍👩", "\u{301}".repeat(129)),
    ] {
        count += verify_all_offsets(&text, true);
    }
    let atoms = [
        "a", " ", "\r", "\n", "é", "\u{301}", "\u{200d}", "👩", "🏽", "🇬", "🇧", "\u{600}", "क", "्",
        "ᄀ", "ᅡ", "ᆨ",
    ];
    let mut seed = 0xce6a_54a9_7d83_92f1;
    for _ in 0..500 {
        let mut text = String::new();
        for _ in 0..(fixtures::random(&mut seed) % 48) {
            text.push_str(atoms[fixtures::random(&mut seed) as usize % atoms.len()]);
        }
        count += verify_all_offsets(&text, true);
    }
    for target in [1_000, 10_000, 100_000] {
        for kind in ["ascii", "multilingual", "emoji"] {
            count += verify_all_offsets(&fixtures::script(kind, target), target <= 1_000);
        }
    }
    eprintln!(
        "Verified {count} byte offsets, both directions; direct original comparison for all short cases and every997th long-script offset; all long offsets use the exact original forward/reverse iterator as oracle."
    );
}

fn run(case: &Case, navigate: Navigate, iterations: usize) -> f64 {
    let started = Instant::now();
    match &case.operation {
        Operation::Queries(offsets) => {
            for i in 0..iterations {
                black_box(navigate(
                    black_box(&case.text),
                    black_box(offsets[i % offsets.len()]),
                ));
            }
        }
        Operation::Traversal { start, steps } => {
            for _ in 0..iterations {
                let mut offset = *start;
                for _ in 0..*steps {
                    offset = navigate(black_box(&case.text), black_box(offset));
                }
                black_box(offset);
            }
        }
    }
    started.elapsed().as_nanos() as f64 / (iterations * case.operation.steps()) as f64
}

fn iterations(case: &Case, navigate: Navigate, target_ms: f64) -> usize {
    let pilot_iterations = if case.operation.steps() > 1 { 1 } else { 32 };
    let pilot = run(case, navigate, pilot_iterations);
    ((target_ms * 1_000_000. / (pilot * case.operation.steps() as f64)) as usize)
        .clamp(1, 2_000_000)
}

fn main() {
    if std::env::var_os("CAP_GRAPHEME_SKIP_VERIFY").is_none() {
        verify();
    }
    if std::env::var_os("CAP_GRAPHEME_VERIFY_ONLY").is_some() {
        return;
    }
    let variant = std::env::var("CAP_GRAPHEME_VARIANT").unwrap_or_else(|_| "both".into());
    assert!(["both", "baseline", "candidate"].contains(&variant.as_str()));
    let target_ms: f64 = std::env::var("CAP_GRAPHEME_SAMPLE_MS")
        .ok()
        .map(|value| value.parse().unwrap())
        .unwrap_or(10.);
    let filter = std::env::var("CAP_GRAPHEME_CASE_FILTER").unwrap_or_default();
    let reverse = std::env::var("CAP_GRAPHEME_ORDER").is_ok_and(|value| value == "BA");
    println!(
        "case,bytes,characters,words,region,direction,operation,steps,variant,sample,iterations,ns_per_step"
    );
    for case in cases()
        .into_iter()
        .filter(|case| case.name.contains(&filter))
    {
        let baseline = case.direction.baseline();
        let candidate = case.direction.candidate();
        let baseline_iterations = if variant == "candidate" {
            1
        } else {
            iterations(&case, baseline, target_ms)
        };
        let candidate_iterations = if variant == "baseline" {
            1
        } else {
            iterations(&case, candidate, target_ms)
        };
        for sample in 0..7 {
            let mut variants = [
                ("baseline", baseline, baseline_iterations),
                ("candidate", candidate, candidate_iterations),
            ];
            if (sample % 2 == 1) ^ reverse {
                variants.reverse();
            }
            for (name, navigate, iterations) in variants {
                if variant != "both" && variant != name {
                    continue;
                }
                let ns = run(&case, navigate, iterations);
                println!(
                    "{},{},{},{},{},{},{},{},{name},{sample},{iterations},{ns:.6}",
                    case.name,
                    case.text.len(),
                    case.text.chars().count(),
                    case.text.split_whitespace().count(),
                    case.region,
                    case.direction.name(),
                    case.operation.name(),
                    case.operation.steps()
                );
            }
        }
    }
}
