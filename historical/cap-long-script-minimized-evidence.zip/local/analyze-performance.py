from pathlib import Path
import csv,json,math,statistics
p=Path(__file__).resolve().parent
result={}
for folder,pairs in [('performance-results',3),('performance-control',5),('performance-repeat',5)]:
 q=p/folder;rows=list(csv.DictReader((q/'summary.csv').open()));columns=list(rows[0]);keys=columns[:columns.index('baseline_median_ns')];g={}
 for pair in range(1,pairs+1):
  for variant in ['baseline','candidate']:
   groups={}
   for r in csv.DictReader((q/f'pair-{pair}-{variant}.csv').open()):groups.setdefault(tuple(r[k] for k in keys),[]).append((int(r['sample']),float(r['ns_per_step'])))
   assert len(groups)==66
   for k,values in groups.items():
    assert sorted(i for i,t in values)==list(range(1,8)) and all(t>0 and math.isfinite(t) for i,t in values)
    g.setdefault(k,{})[pair,variant]=statistics.median(t for i,t in values)
 for r in rows:
  k=tuple(r[f] for f in keys);v=g[k];a=[v[i,'baseline'] for i in range(1,pairs+1)];b=[v[i,'candidate'] for i in range(1,pairs+1)]
  for col,val in [('baseline_median_ns',statistics.median(a)),('candidate_median_ns',statistics.median(b)),('median_paired_speedup',statistics.median(x/y for x,y in zip(a,b)))]:assert math.isclose(float(r[col]),val,rel_tol=1e-12)
 groups={}
 for scope in ['action_handler','key_dispatch','scroll_redraw']:
  values=[float(x['median_paired_speedup']) for x in rows if x['scope']==scope]
  groups[scope]={'min':min(values),'median':statistics.median(values),'max':max(values)}
 result[folder]={'pairs':pairs,'cases':66,'raw_samples':66*7*2*pairs,'summary_discrepancies':0,'original_over_smaller':groups}
(p/'performance-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
