#!/usr/bin/env bash
set -euo pipefail
source /Users/user/Documents/Codex/2026-10-24/ok-x20/work/review/test-env.sh
mini_dir=/Users/user/Documents/Codex/2026-10-24/ok-x20/work/minimize
export CAP_GPUI_APP_DATA_DIR="$mini_dir/profile"
export CAP_GPUI_TAURI_STORE="$mini_dir/profile/store"
export CAP_GPUI_LOG_DIR="$mini_dir/profile/logs"
export CAP_REVIEW_SNAPSHOT="$mini_dir/geometry.json"
mkdir -p "$CAP_GPUI_APP_DATA_DIR"
ln -sfn "$repo_dir/target/Frameworks" "$mini_dir/Frameworks"
"$mini_dir/smaller-tests" --test-threads=1 > "$mini_dir/tests.log" 2>&1
"$mini_dir/smaller-tests" --exact ui::text_input::layout_cache_diagnostic::diagnose_text_input_layout_cache --ignored --nocapture --test-threads=1 > "$mini_dir/cache-diagnostic.log" 2>&1
python3 - "$mini_dir" <<'PY'
from pathlib import Path
import sys,json
p=Path(sys.argv[1]);b=p.parent/'review/baseline-geometry.json'
a=json.loads((p/'geometry.json').read_text());assert len(a)==480
assert a==json.loads(b.read_text())
(p/'geometry-comparison.json').write_text(json.dumps({'cases':480,'identical_to_baseline':True},indent=2)+'\n')
print('All 480 geometry snapshots match the baseline.')
PY
tail -n 4 "$mini_dir/tests.log"
cat "$mini_dir/cache-diagnostic.log"
