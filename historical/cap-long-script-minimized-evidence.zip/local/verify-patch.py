from pathlib import Path
import subprocess,os,json,hashlib
p=Path(__file__).resolve().parent;root=p.parents[1];repo=root/'work/Cap';patch=root/'outputs/cap-long-script-minimized.patch'
env=os.environ.copy();env.update(GIT_INDEX_FILE=str(p/'verification.index'),GIT_OBJECT_DIRECTORY=str(p/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/Users/user/Cap/.git/objects',GIT_NO_LAZY_FETCH='1')
(p/'objects').mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,env=env,text=True).strip()
base='f510acfa1846552a490bfcc3267910218c606364';upstream='6f81ac9662c01748caac76a1d6424043be736550';target='apps/desktop-gpui/src/ui/text_input.rs'
git('read-tree',base);git('apply','--cached',str(patch));blob=git('ls-files','--stage',target).split()[1];content=subprocess.check_output(['git','cat-file','blob',blob],cwd=repo,env=env);assert content==(p/'smaller.rs').read_bytes()
git('read-tree',upstream);git('apply','--cached','--check',str(patch))
record={'base':base,'base_result_blob':blob,'source_sha256':hashlib.sha256(content).hexdigest(),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'latest_inspected_upstream':upstream,'applies_cleanly_to_base':True,'applies_cleanly_to_inspected_upstream':True}
(p/'patch-verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
