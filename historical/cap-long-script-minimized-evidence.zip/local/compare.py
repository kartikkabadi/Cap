from pathlib import Path
import json,hashlib,collections
p=Path(__file__).resolve().parent;r=p.parent/'review'
a=json.loads((p/'native/manifest.json').read_text());b=json.loads((p/'native-baseline/manifest.json').read_text())
assert a==b and len(a)==108
record=[]
for x in a:
 i=x['id'];new=(p/f'native/{i:03}.png').read_bytes();old=(p/f'native-baseline/{i:03}.png').read_bytes();assert new==old,i
 record.append({'id':i,'sha256':hashlib.sha256(new).hexdigest()})
(p/'native-comparison.json').write_text(json.dumps({'cases':108,'identical_to_baseline':True,'png_bytes_identical':True,'records':record},indent=2)+'\n')
def messages(path):
 rows=[json.loads(s) for s in path.read_text().splitlines()]
 return [x['message'] for x in rows if x.get('reason')=='compiler-message' and 'cap-desktop-gpui' in x.get('package_id','') and x['message']['level'] in ['warning','error']]
def key(m):return (m.get('code',{}).get('code') if m.get('code') else None,m['message'])
before=messages(r/'baseline-clippy.jsonl');after=messages(p/'clippy.jsonl')
x=collections.Counter(map(key,before));y=collections.Counter(map(key,after))
assert x==y,(x-y,y-x)
changed=[m for m in after if any(z['file_name'].endswith('ui/text_input.rs') for z in m['spans'])]
assert not changed,changed
(p/'clippy-comparison.json').write_text(json.dumps({'baseline_diagnostics':len(before),'smaller_diagnostics':len(after),'new_diagnostics':0,'changed_file_diagnostics':len(changed),'identical_diagnostic_messages':True},indent=2)+'\n')
print(f'Native: {len(a)} identical PNGs. Clippy: {len(after)} existing diagnostics, zero new.')
