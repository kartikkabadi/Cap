#!/usr/bin/env bash
set -euo pipefail
base_dir=/Users/user/Documents/Codex/2026-10-24/ok-x20
repo_dir="$base_dir/work/Cap"
out_dir="$base_dir/work/minimize"
export PATH="/Users/user/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin:$PATH"
export RUSTC=/Users/user/.rustup/toolchains/1.95.0-aarch64-apple-darwin/bin/rustc
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=2
export CARGO_TARGET_DIR="$base_dir/work/gpui-target"
cd "$repo_dir"
cargo test --manifest-path apps/desktop-gpui/Cargo.toml --locked --offline --bin cap-gpui --no-run \
 --config profile.dev.package.cap-desktop-gpui.opt-level=3 \
 --config profile.dev.package.cap-desktop-gpui.debug=0 \
 --config 'profile.dev.package."*".debug=0' --message-format=json > "$out_dir/build.jsonl" 2> "$out_dir/build.log"
python3 - "$out_dir" <<'PY'
import sys,json,shutil,hashlib
from pathlib import Path
p=Path(sys.argv[1]);r=[json.loads(s) for s in (p/'build.jsonl').read_text().splitlines()]
a=next(x for x in reversed(r) if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']=='cap-gpui')
shutil.copy2(a['executable'],p/'smaller-tests');(p/'profile.json').write_text(json.dumps(a,indent=2)+'\n')
print('Built smaller tests',hashlib.sha256((p/'smaller-tests').read_bytes()).hexdigest())
PY
