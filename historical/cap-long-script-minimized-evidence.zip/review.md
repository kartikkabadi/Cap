# Smaller Cap text-input patch

The final patch changes one file: **+487 / −72**, down from **+673 / −71**. That is 185 fewer changed lines, a **25% reduction**, and 187 fewer net lines of code.

| Scope | Original | Smaller |
| --- | ---: | ---: |
| Production | +200 / −69 | +192 / −70 |
| Tests | +473 / −2 | +295 / −2 |
| Total | +673 / −71 | +487 / −72 |

## What was reduced

Removed one forwarding layout function and passed the already-required layout key directly at its call sites. A mechanical source comparison confirms that all other production code is identical to the audited implementation. Unicode navigation, inherited font handling, font/color invalidation, the bounded four-entry width cache and conservative paragraph culling remain unchanged.

Consolidated repeated test setup and assertions. The repository retains its 25 existing TextInput tests plus five focused regressions covering every byte offset in the explicit Unicode fixtures, fractional wrapped-row clipping, width measurement/cache retention, resize/text/style invalidation and inherited fonts across deferred layout.

The original seven added audit regressions, including the seeded Unicode matrix and glyph-by-glyph clipping oracle, are preserved outside the repository diff and were rerun against the smaller implementation. Only their private layout-call signatures needed adapting. The evidence bundle includes those sources. They are additional audit checks, not automatically registered in the final repository patch.

A one-entry width cache was considered and abandoned before final validation. It saved few lines and could repeat work when flex layout revisits several widths. The original four-entry cache remains.

## Verification

- **1,366 tests passed, zero failures, 19 ignored.** This run includes the five focused repository regressions, seven preserved original audit regressions and two independent geometry/composition checks. The ignored cache diagnostic and viewport benchmark were run explicitly afterward; the other 17 ignored tests remain outside this audit.
- The actual-window cache-retention diagnostic passes for right-arrow, Shift-right and scroll.
- **480 geometry/selection/hit-test snapshots match the unchanged upstream baseline exactly.**
- **108 native font/Metal captures match the baseline exactly**, including their encoded PNG bytes and geometry manifests. Four additional cached-versus-fresh native font/color checks pass. The comparison was rerun at the current 2× Retina scale because the earlier audit used a 1× display. Display scaling differences were not treated as source regressions.
- Scoped binary/test Clippy succeeds with the same 30 pre-existing app diagnostics, zero new diagnostics and none in the changed file. Rust 1.95.0 rustfmt and patch-whitespace checks pass.
- The first restricted full-suite run denied local sockets and native graphics access. It is retained as `tests-sandbox-denied.log`; the complete rerun with those capabilities passed. No failures were waived and no checks were weakened to pass.

## Warm CPU comparison

Compared the audited optimized candidate with the smaller candidate using three alternating process pairs, then a five-pair repeat across the same 66 cases. An additional five-pair same-binary control measured host noise. All **12,012 raw samples** independently reproduce their summary values.

For the five-pair repeat, median original/smaller ratios across cases were **0.991 for handlers, 0.989 for key dispatch/CPU drawing and 0.971 for scroll redraw**, close to equal time. Individual cases varied. The same-binary control itself reported medians of 0.992, 0.849 and 0.918 respectively, with apparent differences approaching 1.9× in individual cases despite executing identical binaries.

These measurements do not establish a consistent performance regression from the simplification. The implementation retains the audited performance algorithms; precise small timing differences cannot be separated from this shared host's variability. No new absolute speedup claim against upstream is made here. The earlier scoped CPU results and their limitations remain documented in the original review.

## Patch integrity and remaining scope

Base: `f510acfa1846552a490bfcc3267910218c606364`.

Smaller whole-file SHA-256: `ead05bbfcbc7e5810eaece48be8a49c1c59e33fa0eb161fd9b8b81acaf09d78c`.

Patch SHA-256: `01a60ba18dcb10cc66bca539fe122df9affd3aba2a23565be64d5150d99d2623`.

The exported patch independently applies to a temporary index at the base and yields the exact smaller source. It also checks cleanly against the last inspected upstream `6f81ac9662c01748caac76a1d6424043be736550`. This minimization did not refresh GitHub or retest all newer upstream commits.

The worktree contains only the intended one-file change. Audit includes and the temporary native example were removed. Full signed-in UI acceptance, system IME entry, native Windows/Linux execution, native FPS and release-profile performance remain unverified as stated in the original review.

This is the smallest version I recommend while retaining useful CI regressions. Further large reductions would primarily remove those guards or alter the performance design. Nothing was committed, pushed or opened as a PR.

Use `cap-long-script-minimized.patch` for the reduced change. `cap-long-script-minimized-evidence.zip` contains the sources, preserved audit tests, build/test logs, repeated measurements, native captures, provenance and a checksum manifest.
