# Minimized text-input audit evidence

This bundle accompanies `cap-long-script-minimized.patch`. It is an independent follow-up to the original archive audit. The final source and patch hashes are in `local/final-verification.json` and `local/patch-verification.json`. The original ZIP in Downloads was not changed.

The repository patch contains 30 TextInput tests, including five focused regressions. `local/exhaustive-regressions.rs` preserves all seven added tests from the original candidate, adapting their calls to the private layout API after the forwarding wrapper was removed. `fixtures/independent-text-input.rs` supplies two independent checks. These extra tests are audit tools rather than files in the final repository patch.

To rebuild the full audit binary, append cfg(test) include! directives to the smaller whole-file source for the exhaustive regressions, independent tests, viewport benchmark and cache diagnostic. Use absolute paths to those files. For the separate native example, append a cfg(not(test)) include! for native-module.rs and use native-main.rs as the example entry point. The build scripts record the exact Rust 1.95.0 locked/offline compiler settings. They contain actual workspace paths, which must be adjusted when reproducing elsewhere. The original repository setup steps and native libraries from the earlier audit are still required.

`local/tests.log` is the successful complete run. `local/tests-sandbox-denied.log` records the preceding restricted run that could not open local sockets or use a graphics adapter. No test was removed or changed to resolve those environmental denials. The full rerun passed with the required host capabilities.

`local/native/` and `local/native-baseline/` contain fresh 2x Retina captures, matching geometry manifests and 108 byte-identical PNG pairs. The earlier 1x captures are in the previous evidence bundle. The native fixture also checks four cached/fresh font/color transitions.

Performance directories:

- `performance-results`: first three-pair original-candidate versus minimized-candidate comparison.
- `performance-control`: five pairs using the exact same original-candidate executable for both labels. This quantifies host/process noise.
- `performance-repeat`: five-pair original-candidate versus minimized-candidate repeat.

Here, "baseline" in performance CSVs means the previously audited optimized candidate, not unmodified upstream. "candidate" means the smaller version, except in the same-binary control. Both compiler profiles are included. All 12,012 raw samples recompute without summary discrepancies. See performance-audit.json for the results and the report for their limits. The measured scope is synthetic warm CPU work; native display latency is not timed.

Build caches, app profiles and native executables are excluded. The production file in the actual worktree has been restored to the smaller source, with no audit includes or temporary example left in the patch. No commit, push or PR occurred. Every packaged file except MANIFEST.json has its size and SHA-256 recorded in that manifest.
